'use client'

import React from 'react'
import Link from 'next/link'
import { ShoppingCart, Heart } from 'lucide-react'
import { Card, CardImage, CardContent } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { useCart } from '@/hooks/useCart'
import type { Product } from '@/lib/db'

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart()

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    addItem({
      id: product.id!,
      name: product.name,
      price: product.price,
      image: product.images[0] || '/images/placeholder.jpg',
    })
  }

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0

  return (
    <Card className="group h-full flex flex-col">
      <Link href={`/products/${product.id}`} className="flex-1 flex flex-col">
        <div className="relative aspect-square">
          <CardImage
            src={product.images[0] || 'https://via.placeholder.com/400x400?text=No+Image'}
            alt={product.name}
            className="absolute inset-0"
          />
          {discount > 0 && (
            <div className="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded">
              -{discount}%
            </div>
          )}
          {!product.inStock && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <span className="bg-gray-900 text-white px-4 py-2 rounded-lg font-medium">
                Out of Stock
              </span>
            </div>
          )}
          <button className="absolute top-2 right-2 p-2 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity hover:bg-gray-100">
            <Heart className="w-4 h-4 text-gray-600" />
          </button>
        </div>
        <CardContent className="flex-1 flex flex-col">
          <Badge variant="secondary" className="self-start mb-2">
            {product.brand}
          </Badge>
          <h3 className="font-semibold text-gray-900 mb-1 line-clamp-2">{product.name}</h3>
          <p className="text-sm text-gray-500 mb-2 line-clamp-1">{product.specs.screen}</p>
          <div className="mt-auto flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-lg font-bold text-primary-600">${product.price}</span>
              {product.originalPrice && (
                <span className="text-sm text-gray-400 line-through">
                  ${product.originalPrice}
                </span>
              )}
            </div>
          </div>
        </CardContent>
      </Link>
      <CardContent className="pt-0">
        <Button
          onClick={handleAddToCart}
          disabled={!product.inStock}
          variant="primary"
          className="w-full"
          size="sm"
        >
          <ShoppingCart className="w-4 h-4 mr-2" />
          Add to Cart
        </Button>
      </CardContent>
    </Card>
  )
}
