import { db, storage } from './firebase'
import {
  collection,
  doc,
  getDocs,
  getDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  Timestamp,
} from 'firebase/firestore'
import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage'

// Types
export interface Product {
  id?: string
  name: string
  brand: string
  price: number
  originalPrice?: number
  description: string
  specs: {
    screen: string
    storage: string
    ram: string
    battery: string
    camera: string
  }
  images: string[]
  inStock: boolean
  featured: boolean
  createdAt?: Timestamp
  updatedAt?: Timestamp
}

export interface Order {
  id?: string
  customerName: string
  phone: string
  address: string
  city: string
  products: {
    productId: string
    name: string
    price: number
    quantity: number
  }[]
  totalAmount: number
  status: 'pending' | 'processing' | 'delivered' | 'cancelled'
  createdAt?: Timestamp
}

// Products
export async function getProducts(): Promise<Product[]> {
  const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'))
  const snapshot = await getDocs(q)
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Product))
}

export async function getFeaturedProducts(): Promise<Product[]> {
  const q = query(
    collection(db, 'products'),
    where('featured', '==', true),
    where('inStock', '==', true)
  )
  const snapshot = await getDocs(q)
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Product))
}

export async function getProductById(id: string): Promise<Product | null> {
  const docRef = doc(db, 'products', id)
  const snapshot = await getDoc(docRef)
  if (!snapshot.exists()) return null
  return { id: snapshot.id, ...snapshot.data() } as Product
}

export async function addProduct(product: Omit<Product, 'id'>): Promise<string> {
  const docRef = await addDoc(collection(db, 'products'), {
    ...product,
    createdAt: Timestamp.now(),
    updatedAt: Timestamp.now(),
  })
  return docRef.id
}

export async function updateProduct(id: string, product: Partial<Product>): Promise<void> {
  const docRef = doc(db, 'products', id)
  await updateDoc(docRef, {
    ...product,
    updatedAt: Timestamp.now(),
  })
}

export async function deleteProduct(id: string): Promise<void> {
  const docRef = doc(db, 'products', id)
  await deleteDoc(docRef)
}

// Image Upload
export async function uploadProductImage(file: File, productId: string): Promise<string> {
  const storageRef = ref(storage, `products/${productId}/${Date.now()}_${file.name}`)
  await uploadBytes(storageRef, file)
  const url = await getDownloadURL(storageRef)
  return url
}

export async function deleteProductImage(imageUrl: string): Promise<void> {
  const storageRef = ref(storage, imageUrl)
  await deleteObject(storageRef)
}

// Orders
export async function createOrder(order: Omit<Order, 'id'>): Promise<string> {
  const docRef = await addDoc(collection(db, 'orders'), {
    ...order,
    createdAt: Timestamp.now(),
  })
  return docRef.id
}

export async function getOrders(): Promise<Order[]> {
  const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'))
  const snapshot = await getDocs(q)
  return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Order))
}

export async function updateOrderStatus(id: string, status: Order['status']): Promise<void> {
  const docRef = doc(db, 'orders', id)
  await updateDoc(docRef, { status })
}
